from django.contrib import admin
from .models import Products,Contact,Order,Users,Latest
# Register your models here.
admin.site.register(Products)
admin.site.register(Contact)
admin.site.register(Order)
admin.site.register(Latest)
admin.site.register(Users)


